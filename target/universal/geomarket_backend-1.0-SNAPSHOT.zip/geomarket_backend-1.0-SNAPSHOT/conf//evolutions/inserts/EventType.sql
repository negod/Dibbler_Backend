INSERT INTO `geomarket`.`event_type` (`NAME_ENG`, `DESCRIPTION_ENG`, `NAME_SWE`, `DESCRIPTION_SWE`) VALUES ('10%','10% discount from normal prize','10%', '10% rabatt på normala priset');
INSERT INTO `geomarket`.`event_type` (`NAME_ENG`, `DESCRIPTION_ENG`, `NAME_SWE`, `DESCRIPTION_SWE`) VALUES ('AW', 'After work', 'AW', 'After work');
INSERT INTO `geomarket`.`event_type` (`NAME_ENG`, `DESCRIPTION_ENG`, `NAME_SWE`, `DESCRIPTION_SWE`) VALUES ('2 for 1', 'Get 2 for the prize of 1', '2 för 1', 'Få två till priset av en');
INSERT INTO `geomarket`.`event_type` (`NAME_ENG`, `DESCRIPTION_ENG`, `NAME_SWE`, `DESCRIPTION_SWE`) VALUES ('25%', '25% discount from normal prize', '25%', '25% rabatt på normala priset');
