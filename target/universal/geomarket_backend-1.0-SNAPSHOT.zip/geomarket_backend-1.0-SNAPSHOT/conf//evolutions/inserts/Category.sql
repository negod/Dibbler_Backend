INSERT INTO `geomarket`.`category` (`NAME_ENG`, `NAME_SWE`) VALUES ('Food', 'Mat');
INSERT INTO `geomarket`.`category` (`NAME_ENG`, `NAME_SWE`) VALUES ('Tickets', 'Biljetter');
INSERT INTO `geomarket`.`category` (`NAME_ENG`, `NAME_SWE`) VALUES ('Discount', 'Rabatt');